#Wifresti

Find your wireless network password from Windows , Linux and Mac OS

Wifresti is a simple Wi-Fi password recovery tool , compatible with Windows , and Unix systems (Linux , Mac OS) .


#Features
- Recover Wifi password on Windows
- Recover Wifi password on Unix

#Requirements

- An operating system (tested on Ubuntu, Windows 10,8,7)
- Python 2.7

#Instalation 
- sudo su
- git clone https://github.com/LionSec/wifresti.git && cp wifresti/wifresti.py /usr/bin/wifresti && chmod +x /usr/bin/wifresti
- sudo wifresti

#Without Python (.exe file)

If you do not have Python installed, you can also download the executable version (Only for Windows)
- Download link : http://lionsec.net/tools/download.php?Down=wifresti_windows.zip

#I have some questions!

Please visit https://github.com/LionSec/wifresti/issues

#Contact
- Website : http://lionsec.net
- Youtube : https://youtube.com/inf98es
- Facebook : https://facebook.com/in98
- Twitter: @LionSec1
- Email : informatica98es@gmail.com

